-- Memory World v2.0.1
-- New project: run this once in Supabase Dashboard -> SQL Editor.
-- Target project: https://aypfjfelemuhgxyfzbgo.supabase.co
-- Existing projects that already ran the v1.4.0 setup do not need to run this again.

begin;

create table if not exists public.memory_world_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  schema_version text not null default '2.0.1',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.memory_world_user_data
  alter column schema_version set default '2.0.1';

alter table public.memory_world_user_data enable row level security;

-- Re-running this file is safe.
drop policy if exists "memory_world_select_own" on public.memory_world_user_data;
drop policy if exists "memory_world_insert_own" on public.memory_world_user_data;
drop policy if exists "memory_world_update_own" on public.memory_world_user_data;
drop policy if exists "memory_world_delete_own" on public.memory_world_user_data;

create policy "memory_world_select_own"
on public.memory_world_user_data
for select
to authenticated
using ((select auth.uid()) = user_id);

create policy "memory_world_insert_own"
on public.memory_world_user_data
for insert
to authenticated
with check ((select auth.uid()) = user_id);

create policy "memory_world_update_own"
on public.memory_world_user_data
for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "memory_world_delete_own"
on public.memory_world_user_data
for delete
to authenticated
using ((select auth.uid()) = user_id);

revoke all on table public.memory_world_user_data from anon;
grant select, insert, update, delete on table public.memory_world_user_data to authenticated;

comment on table public.memory_world_user_data is
  'One isolated Memory World JSON document per authenticated Supabase user.';

commit;
